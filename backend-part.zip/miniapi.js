const express=require('express');
const cors=require('cors');
const bodyParser=require('body-parser');
const sha1=require('sha1');


const mongoose=require('mongoose');
//connect mongoose to mongodb 
mongoose.connect("mongodb://localhost/appointmentDB", {
    useCreateIndex: true,
    useNewUrlParser: true
  });
  let loginModel=require('./database/login');
  let dateSlot=require('./database/dateslot');



  let app=express();
app.use(cors());
app.use(bodyParser.json());


app.post('/api/signupdata',function(req,res)
{
    
    let email=req.body.email;
    let password=req.body.password;
    let ins=new loginModel({'email':email,'password':password});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                  res.json({'err':0,'msg':'data saved'})
               }
           })

})




app.post('/api/logindata',function(req,res)
{
    let email=req.body.email;
    let password=req.body.password;


   
loginModel.find({'email':email,'password':password},function(err,data)
    {
       if(err){}
       else if(data.length==0)
       {
           res.json({'err':1,'msg':'Email or password is not correct'})
       }
       else
       {
           myemail=data[0].email;
           res.json({'err':0,'msg':'login succes','user':email});
           
       }
    })

})




app.post('/api/postdate',function(req,res){
    let email=req.body.email;
    let date=req.body.date;
    console.log(email+" "+date+"djfgnfj");
  
    let slots=[false,false,false,false,false,false,false,false,false,false];
  
     let ins=new dateSlot({'email':email,'date':date,'slots':slots});
             ins.save(function(err)
             {
                 if(err){}
                 else
                 {
                     res.json({'err':0,'msg':'Data Saved'});
                   }
             })
  
  
  })
  
  
  app.post('/api/getslot',function(req,res){
  
      let email=req.body.email;
      let date=req.body.date;
  
      console.log(email+" "+date+"hjgyjfjvjf");
  
      dateSlot.find({'email':email,'date':date},function(err,data){
      if (err){}
        else{
          res.json({'err':0,'data':data});
        }
    })
  })
  
  app.post('/api/markbook',function(req,res){
      let email=req.body.email;
      let date=req.body.date;
      let index=req.body.index;
  
      dateSlot.find({'email':email,'date':date},function(err,data){
      if (err){}
        else{
          res.json({'err':0,'data':data});
  
          let slot=data[0].slots;
          slot[index]=true;
  
          console.log(slot);
  
            dateSlot.updateOne({'email':email,date:'date'},{$set:{'slots':slot}},function(err){
      if (err){
      }
        else{
          res.json({'err':0,'msg':'booked'});
        }
    })
        }
    })
  
  
  })
  




// app.post('/api/doctordata',function(req,res)
// {    
//     let name=req.body.name;
//     let id=req.body.regid;
//     let email=req.body.email;
//     let regid=req.body.regid;
//     let education=req.body.education;
//     let address=req.body.address;
//     let start=req.body.start;
//     let end=req.body.end;
//     let password=sha1(req.body.confirmpassword);
    

//     // let email=req.body.email;
//     // let password=sha1(req.body.password);

//    // for insert data 
//     let ins=new doctorModel({'name':name,'id':id,'email':email,'regid':regid,'education':education,'address':address,'start':start,'end':end,'password':password});
//     ins.save(function(err)
//     {
//         if(err){}
//         else
//         {
//             res.json({'msg':'Data Save'})
//         }
//     })



// })



app.listen(7788,function()
{
    console.log("Work on 7788");
})