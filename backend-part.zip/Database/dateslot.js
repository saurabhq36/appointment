const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const dateslot = new Schema({
    email:String,
    date:String,
    slots:[false,false,false,false,false,false,false,false,false,false]
});
module.exports = mongoose.model('dateslot',dateslot);