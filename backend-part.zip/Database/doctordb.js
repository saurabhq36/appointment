const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const doctordb = new Schema({
    name:String,
    id:String,
    email:{type:String,unique:true},
    regid:String,
    education:String,
    address:String,
    start:String,
    end:String,
    password:String,
});
module.exports = mongoose.model('doctordb',doctordb);