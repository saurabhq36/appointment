export class Student{
    name:String;
    gender:String;
    age:number;
}