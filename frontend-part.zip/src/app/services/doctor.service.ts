import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  url="http://localhost:7788/api/";
  constructor(private http:HttpClient) {}

  login(data){
    return this.http.post(this.url+"logindata",data);
  }

  signup(data){
    return this.http.post(this.url+"signupdata",data);
  }

  postDate(date){
    return this.http.post(this.url+"postdate",date);
  }

  getSlot(date){
    return this.http.post(this.url+"getslot",date);
  }

  markbook(data){
   return this.http.post(this.url+"markbook",data);
  }

}
