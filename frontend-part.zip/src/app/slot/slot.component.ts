import { Component, OnInit } from '@angular/core';
import { DoctorService } from '../services/doctor.service';
@Component({
  selector: 'app-slot',
  templateUrl: './slot.component.html',
  styleUrls: ['./slot.component.css']
})
export class SlotComponent implements OnInit {
  email;
  date;
  resData;
  data;
  constructor(private dser:DoctorService) { }


  onBook(i){
  	console.log(i);
  	this.email=localStorage.getItem('email');
     this.date=localStorage.getItem('date');
  	let formData={};
     formData['email']=this.email;
     formData['date']=this.date;
     formData['index']=i;
  	this.dser.markbook(formData)
  	.subscribe(res=>{
       console.log(res);
       document.location.reload(true);
  	})
  }

  ngOnInit() {
    this.email=localStorage.getItem('email');
    this.date=localStorage.getItem('date');

    let formData={};
    formData['email']=this.email;
    formData['date']=this.date;

    console.log(formData);

   this.dser.getSlot(formData)
   .subscribe(res=>{
      this.resData=res;
      this.data=this.resData.data;
      console.log(this.data);
   })


  }

}
