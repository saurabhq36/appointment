import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators} from '@angular/forms';
import { DoctorService } from '../services/doctor.service';
import {Router} from '@angular/router';
import { elementEventFullName } from '@angular/compiler/src/view_compiler/view_compiler';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  myForm:FormGroup;
  showslot:false;
  email;
  
  
  constructor(private fb:FormBuilder,private dser:DoctorService,private router:Router) { }

  showslots(value){
    console.log(value);
    this.email=localStorage.getItem('userId');
  
    localStorage.setItem('date',this.myForm.controls.date.value);
    localStorage.setItem('email',this.email);
  
    let formData=this.myForm.getRawValue();
      formData['email']=this.email;
    this.dser.postDate(formData)
    .subscribe(res=>{
      console.log(res);
    })
  
  this.router.navigate(['\slot']);
  }
  

  ngOnInit() {
    this.validate();
  }

  validate(){
  	this.myForm=this.fb.group(
      {
       'date':['',Validators.required]
      }
    )
  }

}
