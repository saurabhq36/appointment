import { Component, OnInit } from '@angular/core';
import { DoctorService } from '../services/doctor.service';
import { Router} from '@angular/router';
import { FormGroup, FormBuilder, Validators,FormControl } from '@angular/forms';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  myForm:FormGroup;
  resData;
  errMsg;
  constructor(private fb:FormBuilder,private router:Router,private lser:DoctorService) { }

  loginSubmit()
  {
     let formData=this.myForm.getRawValue();
     console.log(formData);
     this.lser.login(formData)
     .subscribe(res=>
      {
        this.resData=res;
        
        if(this.resData.err==0)
        {
          
          
          
          // Swal.fire({
          //   position: 'center',
          //   type: 'success',
          //   title: 'logged in',
          //   showConfirmButton: false,
          //   timer: 1500
          // })
          Swal.fire({
            // title: "Good job!",
            text: "signedup sucessfully!",
            icon: "success",
            timer:1500
          });
          
          
          localStorage.setItem('userId',this.resData.user);
          localStorage.setItem('var1',"true");
          localStorage.setItem('var2',"true");
          this.router.navigate(['/dashboard'])
          
        }
        if(this.resData.err==1)
        {
           this.errMsg=this.resData.msg;
        
        
        
        // Swal.fire({
        //     position: 'center',
        //     type: 'error',
        //     title: 'logged in',
        //     showConfirmButton: false,
        //     timer: 1500
        //   })
        
        
        
        }
      },err=>
      {
        console.log("api error");
      })
  }




  ngOnInit() {
    this.validate();
  }


  validate()
  {
    this.myForm=this.fb.group(
      {'email':['',Validators.required],
     'password':['',Validators.required]
     }
    )
  }


}





