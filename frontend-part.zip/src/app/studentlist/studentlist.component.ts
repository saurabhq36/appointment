import { Component, OnInit } from '@angular/core';
import { Student } from 'src/model/student.model';

@Component({
  selector: 'app-studentlist',
  templateUrl: './studentlist.component.html',
  styleUrls: ['./studentlist.component.css']
})
export class StudentlistComponent implements OnInit {
students:Student[]=[{name:"saurabh",gender:"m",age:23},{name:"abc",gender:"m",age:23}]
  constructor() { }

  ngOnInit() {
  }

}
