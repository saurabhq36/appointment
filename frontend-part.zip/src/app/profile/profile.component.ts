import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { DoctorService } from '../services/doctor.service';
import { FormGroup, FormBuilder, Validators,FormControl } from '@angular/forms';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  // myForm = new FormGroup({
  //   Name: new FormControl(),
  //   id:new FormControl(),
  //   email:new FormControl(),
  //   regid:new FormControl(),
  //   education:new FormControl(),
  //   address:new FormControl(),
  //   start:new FormControl(),
  //   end:new FormControl(),
  //   password:new FormControl(),
  //   confirmpassword:new FormControl()

  //  });
  constructor(private fb:FormBuilder,private router:Router,private lser:DoctorService) { }
  myForm:FormGroup;
  resData;
  errMsg;
  // Submit()
  // {
  //   let formData=this.myForm.getRawValue();
  //   console.log(formData);
  //   this.lser.Doctordata(formData)
  //   .subscribe(res=>
  //     {
  //        this.resData=res;
  //        if(this.resData.err==0)
  //        {
  //         console.log("data inserted");
  //        }
  //     })
  // }


  loginSubmit()
  {
     let formData=this.myForm.getRawValue();
     //console.log(formData);
     this.lser.signup(formData).subscribe(res=>
      {
           console.log(res)
          //  Swal.fire({
          //   position: 'center',
          //   type: 'success',
          //   title: 'sucessfully signed up ',
          //   showConfirmButton: false,
          //   timer: 3000
          // })
          Swal.fire({
            // title: "Good job!",
            position: 'center',
            text: "signedup sucessfully!",
            icon: "success",
            timer: 3000
          });

           this.router.navigate(['/'])
      })
  }



  ngOnInit() {
    this.validate();
  }

  validate()
  {
    this.myForm=this.fb.group(
      {'email':['',Validators.required],
     'password':['',Validators.required]
     }
    )
  }

}
