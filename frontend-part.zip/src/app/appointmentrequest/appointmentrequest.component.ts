import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointmentrequest',
  templateUrl: './appointmentrequest.component.html',
  styleUrls: ['./appointmentrequest.component.css']
})
export class AppointmentrequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
